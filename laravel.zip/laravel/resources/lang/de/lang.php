<?php
   return [
      'msg' => 'Laravel Internationalisierung Beispiel.'
   ];
?>
