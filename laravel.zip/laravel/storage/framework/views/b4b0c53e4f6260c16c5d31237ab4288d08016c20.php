<h1>Hi, <?php echo e($name); ?></h1>
l<p>Sending Mail from Laravel.</p>
<?php /**PATH C:\laravel\resources\views/mail.blade.php ENDPATH**/ ?>